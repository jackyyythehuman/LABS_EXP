## How to contribute to Athlon Frontend Webpack Boilerplate

Thank you for contributing to this template!
=========================================

## Language

English is the best language to communicate.

## Templates

Please use issue/PR templates which are inserted automatically.
