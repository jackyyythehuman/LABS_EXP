const demo = () => 'Webpack Boilerplate v5.16.0 - SASS/PostCSS, ES6/7, browser sync, source code listing and more.';

const demo1 = () => {
    // other statements ...
    return 'Webpack Boilerplate v5.16.0 - SASS/PostCSS, ES6/7, browser sync, source code listing and more.';
}

const demo2 = function () {
    // other statements ...
    let demo4 = 5
    console.log(demo4)
        
    console.log(demo5)
    var demo5 = 'test'
    console.log(demo5)


    console.log('0' === false)

    let demo6 = `String ${demo4}`

    console.log(demo6)

    return 'Webpack Boilerplate v7.16.0 - SASS/PostCSS, ES6/7, browser sync, source code listing and more.';
}

const test = {
    'key': 123
}
test.key = 1

const demo3 = demo
console.log(demo2());
